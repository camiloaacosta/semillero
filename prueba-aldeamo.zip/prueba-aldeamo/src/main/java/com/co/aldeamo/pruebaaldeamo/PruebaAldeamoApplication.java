package com.co.aldeamo.pruebaaldeamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaAldeamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaAldeamoApplication.class, args);
	}

}
